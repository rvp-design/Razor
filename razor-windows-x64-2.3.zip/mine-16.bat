@echo off
cd /d "%~dp0"
title Razor 1x16
echo Razor 1.11  16 physical cores  (RandomX L3 layout — try this vs 32)
echo Banner: huge=on  threads=16  aes=hw
echo.
razor.exe --threads 16 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.p16
echo.
pause
