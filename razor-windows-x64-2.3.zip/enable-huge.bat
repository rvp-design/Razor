@echo off
cd /d "%~dp0"
title Razor enable huge pages
echo Razor 1.10  grant Lock pages in memory
echo This pops UAC once. After it succeeds you MUST sign out of Windows.
echo Then sign in and run mine.bat — banner should say huge=on.
echo.
razor.exe --enable-huge
echo.
pause
