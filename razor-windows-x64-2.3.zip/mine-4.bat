@echo off
cd /d "%~dp0"
echo Razor 1.11  4x8 — 4 physical cores + SMT each
start "Razor slice 0/4" /D "%~dp0" cmd /k razor.exe --slice 0/4 --threads 8 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.a
start "Razor slice 1/4" /D "%~dp0" cmd /k razor.exe --slice 1/4 --threads 8 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.b
start "Razor slice 2/4" /D "%~dp0" cmd /k razor.exe --slice 2/4 --threads 8 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.c
start "Razor slice 3/4" /D "%~dp0" cmd /k razor.exe --slice 3/4 --threads 8 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.d
