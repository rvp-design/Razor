Razor 1.12 — ShearHash-v2 CPU miner (Windows x64)

mine.bat / mine-31.bat   31 threads (one logical left for the HUD)
mine-32.bat              32 threads
mine-16.bat              16 physical

1.12 drops HIGH_PRIORITY on the process so the leftover thread can actually
draw the console.

feePct 0. Pool pool.shear.digital:1111.
