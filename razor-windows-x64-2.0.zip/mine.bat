@echo off
cd /d "%~dp0"
title Razor 1x31
echo Razor 1.12  31 threads — one logical CPU left for the HUD / Windows
echo.
razor.exe --threads 31 --no-tune --backend jit-full --pool pool.shear.digital:1111 --user she1q8qs265j8wsfhrtgtufgdfn780q377x65zawsz9.solo
echo.
pause
